#' Extract Data from CMap GCTX Files for Specified Combinations
#'
#' @description Functions to extract expression data from CMap GCTX files based on
#' specified combinations of time points, dosages, and cell lines.
#' @return None; this is an internal documentation topic.
#'
#' @name cmap_extract
#' @keywords internal
NULL

#' Read first existing HDF5 dataset from candidate paths
#' @param fname HDF5/GCTX file path
#' @param paths Candidate dataset paths
#' @return Dataset content
#' @keywords internal
fast_read_meta <- function(fname, paths) {
  for (p in paths) {
    val <- tryCatch(rhdf5::h5read(fname, p), error = function(e) NULL)
    if (!is.null(val)) return(val)
  }
  stop("Could not read metadata from GCTX file. Checked paths: ",
       paste(paths, collapse = ", "))
}

#' Fast parser for GCTX matrices with optional row/column subsetting
#' @param fname Path to GCTX file
#' @param rid Optional character vector of row ids (gene ids)
#' @param cid Optional character vector of column ids (signature ids)
#' @return Numeric matrix with selected rows/columns
#' @keywords internal
fast_parse_gctx <- function(fname, rid = NULL, cid = NULL) {
  if (!file.exists(fname)) {
    stop("GCTX file not found: ", fname)
  }
  if (!requireNamespace("rhdf5", quietly = TRUE)) {
    stop("Package 'rhdf5' is required to read GCTX files")
  }

  row_ids <- as.character(fast_read_meta(fname, c("/0/META/ROW/id", "/META/ROW/id")))
  col_ids <- as.character(fast_read_meta(fname, c("/0/META/COL/id", "/META/COL/id")))

  row_idx <- if (is.null(rid)) {
    seq_along(row_ids)
  } else {
    match(as.character(rid), row_ids)
  }
  col_idx <- if (is.null(cid)) {
    seq_along(col_ids)
  } else {
    match(as.character(cid), col_ids)
  }

  row_idx <- row_idx[!is.na(row_idx)]
  col_idx <- col_idx[!is.na(col_idx)]

  if (length(row_idx) == 0 || length(col_idx) == 0) {
    out <- matrix(numeric(0), nrow = length(row_idx), ncol = length(col_idx))
    if (!is.null(rid)) rownames(out) <- as.character(rid)[!is.na(match(as.character(rid), row_ids))]
    if (!is.null(cid)) colnames(out) <- as.character(cid)[!is.na(match(as.character(cid), col_ids))]
    return(out)
  }

  mat <- tryCatch(
    rhdf5::h5read(fname, "/0/DATA/0/matrix", index = list(row_idx, col_idx)),
    error = function(e) {
      rhdf5::h5read(fname, "/DATA/0/matrix", index = list(row_idx, col_idx))
    }
  )

  mat <- as.matrix(mat)
  rownames(mat) <- row_ids[row_idx]
  colnames(mat) <- col_ids[col_idx]
  mat
}

#' Get Gene IDs and Gene Names for Landmark Genes
#'
#' @param geneinfo_df Data frame containing gene information
#' @return List with rid (gene IDs) and genenames (gene symbols)
#' @keywords internal
get_rid <- function(geneinfo_df,landmark=TRUE) {
  gene_overlapping <- geneinfo_df
  if (landmark)
  {
    gene_overlapping <- gene_overlapping[gene_overlapping$feature_space == "landmark", ]
  }
  
  return(list(
    rid = as.character(gene_overlapping$gene_id),
    genenames = as.character(gene_overlapping$gene_symbol)
  ))
}

#' Process a Single Combination of Time, Dose, and Cell Line
#'
#' @param combination Data frame row containing time, dose, and cell line information
#' @param rid Vector of gene IDs to extract
#' @param genenames Vector of gene names corresponding to the gene IDs
#' @param sig_info Data frame containing signature information
#' @param gctx_file Path to the GCTX file
#' @param output_dir Directory to save output files
#' @return Path to the output file (invisibly)
#' @keywords internal
process_combination <- function(combination, rid, genenames, sig_info,
                                gctx_file = "level5_beta_trt_cp_n720216x12328.gctx",
                                output_dir = ".") {
  itime <- combination$itime
  idose <- combination$idose
  cell <- combination$cell

  message(sprintf("Processing: time=%s, dose=%s, cell=%s", itime, idose, cell))

  # Filter data
  filtered_df <- sig_info[
    sig_info$pert_itime == itime &
      sig_info$pert_idose == idose &
      sig_info$cell_iname == cell,
  ]

  cid <- filtered_df$sig_id

  # Create filename with underscores instead of spaces
  filename <- paste0(
    "filtered_",
    gsub(" ", "_", itime), "_",
    gsub(" ", "_", idose), "_",
    gsub(" ", "_", cell), ".csv"
  )

  # Full path to output file
  output_file <- file.path(output_dir, filename)

  if (length(cid) > 0) {
       # Parse the gctx file
    mat <- fast_parse_gctx(
      fname = gctx_file,
      cid = cid,
      rid = rid
    )
    message(sprintf("Data dimensions: %d x %d", nrow(mat), ncol(mat)))

    if (nrow(mat) > 0) {
      # Convert to data frame and set row names as gene names
      df <- as.data.frame(mat)
      rownames(df) <- genenames

      # Write to file
      utils::write.table(df, file = output_file, sep = "\t", quote = FALSE)
      message(sprintf("Successfully wrote data to %s", output_file))
    } else {
      message(sprintf("No data found for this combination"))
      # Create an empty file with header
      writeLines(paste(
        "# No data found for this combination",
        paste("# Time:", itime),
        paste("# Dose:", idose),
        paste("# Cell:", cell),
        sep = "\n"
      ), output_file)
    }
  } else {
    message(sprintf("No matching signatures found for this combination"))
    # Create an empty file with header
    writeLines(paste(
      "# No matching signatures found for this combination",
      paste("# Time:", itime),
      paste("# Dose:", idose),
      paste("# Cell:", cell),
      sep = "\n"
    ), output_file)
  }

  return(invisible(output_file))
}

#' Process Multiple Combinations of Time, Dose, and Cell Line
#'
#' @param combinations_file Path to a file containing combinations to process
#' @param task_id Specific task ID to process (for SLURM array jobs)
#' @param geneinfo_file Path to the gene info file
#' @param siginfo_file Path to the signature info file
#' @param gctx_file Path to the GCTX file
#' @param output_dir Directory to save output files
#' @return List of processed files (invisibly)
#' @examples
#' combinations <- data.frame(
#'   itime = "24 h",
#'   idose = "1 uM",
#'   cell = "K562",
#'   stringsAsFactors = FALSE
#' )
#' combinations_file <- tempfile(fileext = ".tsv")
#' utils::write.table(
#'   combinations,
#'   combinations_file,
#'   sep = "\t",
#'   row.names = FALSE,
#'   quote = FALSE
#' )
#' file.exists(combinations_file)
#'
#' # With real CMap files available locally, run:
#' # process_combinations_file(
#' #   combinations_file = combinations_file,
#' #   geneinfo_file = "path/to/geneinfo_beta.txt",
#' #   siginfo_file = "path/to/siginfo_beta.txt",
#' #   gctx_file = "path/to/level5_beta_all_n1201944x12328.gctx",
#' #   output_dir = tempdir()
#' # )
#' @export
process_combinations_file <- function(combinations_file, task_id = NULL,
                                      geneinfo_file = "geneinfo_beta.txt",
                                      siginfo_file = "siginfo_beta.txt",
                                      gctx_file = "level5_beta_trt_cp_n720216x12328.gctx",
                                      output_dir = ".") {

  # Create output directory if it doesn't exist
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }

  # Check if combinations file exists
  if (!file.exists(combinations_file)) {
    stop("Combinations file not found: ", combinations_file)
  }

  # Read combinations file
  combinations <- utils::read.table(combinations_file, header = TRUE, stringsAsFactors = FALSE)
  message(sprintf("Loaded %d combinations from %s", nrow(combinations), combinations_file))

  # Read gene info file
  message("Reading gene info file...")
  geneinfo_df <- utils::read.table(geneinfo_file, sep = "\t", header = TRUE, stringsAsFactors = FALSE)
  result <- get_rid(geneinfo_df)
  rid <- result$rid
  genenames <- result$genenames

  # Read siginfo file
  message("Reading signature info file...")
  sig_info <- utils::read.table(siginfo_file, sep = "\t", header = TRUE, stringsAsFactors = FALSE)
  sig_info <- sig_info[sig_info$pert_type == "trt_cp", ]
  sig_info <- sig_info[sig_info$is_hiq == 1, ]

  # Determine execution mode
  # Check if we're running as part of a SLURM array job
  slurm_task_id <- Sys.getenv("SLURM_ARRAY_TASK_ID")

  # Determine which task_id to use
  if (!is.null(task_id)) {
    # Command line argument takes precedence
    task_id <- as.integer(task_id)
    message(sprintf("Using explicit task ID: %d", task_id))
  } else if (slurm_task_id != "") {
    # Next, use SLURM array task ID if available
    task_id <- as.integer(slurm_task_id)
    message(sprintf("Using SLURM array task ID: %d", task_id))
  } else {
    # If neither is available, process all combinations
    task_id <- NULL
    message("No task ID specified. Processing all combinations sequentially.")
  }

  # Process combination(s)
  output_files <- character()

  if (!is.null(task_id)) {
    # Process just one combination
    if (task_id < 1 || task_id > nrow(combinations)) {
      stop("Invalid task ID: ", task_id, ". Must be between 1 and ", nrow(combinations))
    }

    output_file <- process_combination(combinations[task_id, ], rid, genenames, sig_info, gctx_file, output_dir)
    output_files <- c(output_files, output_file)
  } else {
    # Process all combinations
    for (i in seq_len(nrow(combinations))) {
      message(sprintf("\n--- Combination %d of %d ---\n", i, nrow(combinations)))
      output_file <- process_combination(combinations[i, ], rid, genenames, sig_info, gctx_file, output_dir)
      output_files <- c(output_files, output_file)
    }
  }

  return(invisible(output_files))
}